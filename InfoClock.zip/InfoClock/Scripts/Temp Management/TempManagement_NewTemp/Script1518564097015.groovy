import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory as CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as MobileBuiltInKeywords
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testcase.TestCaseFactory as TestCaseFactory
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testdata.TestDataFactory as TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository as ObjectRepository
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WSBuiltInKeywords
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUiBuiltInKeywords
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable

'Login InfoClock'
WebUI.callTestCase(findTestCase('LoginInfoClock'), [('filename') : '\\LoginError.jpg', ('filepath') : 'C:\\Users\\cwright\\Automated Test Results\\InfoClock\\'], 
    FailureHandling.CONTINUE_ON_FAILURE)

'Hover over Configuration menu'
WebUI.mouseOver(findTestObject('Page_Home/img_mm_Configuration'))

'Wait for Temp Management to appear in menu'
WebUI.waitForElementVisible(findTestObject('Page_Home/span_Temp Management'), GlobalVariable.g_MIN_TO)

'Click Temp Management to view page'
WebUI.click(findTestObject('Page_Home/span_Temp Management'))

'Wait for page to load'
WebUI.waitForPageLoad(0)

'Read temp data file'
Read_Temp_Data()

'Scroll to Search field'
WebUI.scrollToElement(findTestObject('Page_Temp Management/Search/h1_Search'), GlobalVariable.g_MIN_TO)

'Click Company drop-down'
WebUI.click(findTestObject('Page_Temp Management/Search/select_Company'))

'Click the Company name using test data'
WebUI.selectOptionByLabel(findTestObject('Page_Temp Management/Search/select_Company'), td_COMPANY, false)

'Click the facility name'
WebUI.click(findTestObject('Page_Temp Management/Search/select_Facility'))

'Click the Facility name using test data'
WebUI.selectOptionByLabel(findTestObject('Page_Temp Management/Search/select_Facility'), td_FACILITY, false)

'Click the category name'
WebUI.click(findTestObject('Page_Temp Management/Search/select_Category'))

'Click the Category name using test data'
WebUI.selectOptionByLabel(findTestObject('Page_Temp Management/Search/select_Category'), td_CATEGORY, false)

'Click the Job Position text field'
WebUI.click(findTestObject('Page_Temp Management/Search/input_JobPosition'))

'Specify the job position'
WebUI.setText(findTestObject('Page_Temp Management/Search/input_JobPosition'), td_JOB)

'Click [New Temp] button'
WebUI.click(findTestObject('Page_Temp Management/Search/button_New Temp'))

'Scroll to Temp Edit section'
WebUI.scrollToElement(findTestObject('Page_Temp Management/Temp Edit/h1_Temp Edit'), GlobalVariable.g_MIN_TO)

'Check if Temp Edit field is present'
if (WebUI.verifyElementVisibleInViewport(findTestObject('Page_Temp Management/Temp Edit/h1_Temp Edit'), GlobalVariable.g_SHORT_TO)) {
    'Verify Company in New Temp section'
    WebUI.verifyOptionSelectedByLabel(findTestObject('Page_Temp Management/Temp Edit/select_Company'), td_COMPANY, false, 
        GlobalVariable.g_MIN_TO)

    'Verify Facility in New Temp section'
    WebUI.verifyOptionSelectedByLabel(findTestObject('Page_Temp Management/Temp Edit/select_Facility'), td_FACILITY, false, 
        GlobalVariable.g_MIN_TO)

    'Verify Category in New Temp section'
    WebUI.verifyOptionSelectedByLabel(findTestObject('Page_Temp Management/Temp Edit/select_Category'), td_CATEGORY, false, 
        GlobalVariable.g_MIN_TO)

    'Verify ID CODE column and Employee Code field display the same ID'
    WebUI.verifyEqual(WebUI.getAttribute(findTestObject('Page_Temp Management/Temp Edit/input_EmployeeCode'), 'value'), 
        WebUI.getText(findTestObject('Page_Temp Management/Data Table/table_IDcode')))

    'Verify Position in New Temp section'
    WebUI.verifyElementAttributeValue(findTestObject('Page_Temp Management/Temp Edit/input_JobPosition'), 'value', td_JOB, 
        0)

    'Verify Department is "Warehouse"'
    WebUI.verifyOptionPresentByLabel(findTestObject('Page_Temp Management/Temp Edit/select_Department'), 'Warehouse', false, 
        GlobalVariable.g_MIN_TO)

    'Get date displayed in Hire Date field'
    displayedDate = new Date(WebUI.getAttribute(findTestObject('Page_Temp Management/Temp Edit/input_HireDate'), 'value'))

    'Verify Hire Date is the current date'
    WebUI.verifyElementText(findTestObject('Page_Temp Management/Temp Edit/input_HireDate'), '', FailureHandling.CONTINUE_ON_FAILURE)

    'Verify Punch By Bar Code is checked'
    WebUI.verifyElementNotChecked(findTestObject('Page_Temp Management/Temp Edit/checkbox_PunchFinger'), GlobalVariable.g_MIN_TO)

    'Verify Active is checked'
    WebUI.verifyElementChecked(findTestObject('Page_Temp Management/Temp Edit/checkbox_PunchBarCode'), GlobalVariable.g_MIN_TO)

    'Verify Supervisor is unchecked'
    WebUI.verifyElementChecked(findTestObject('Page_Temp Management/Temp Edit/checkbox_Active'), GlobalVariable.g_MIN_TO)

    'Verify Active is checked'
    WebUI.verifyElementNotChecked(findTestObject('Page_Temp Management/Temp Edit/checkbox_Supervisor'), GlobalVariable.g_MIN_TO)
} else {
    'Take screenshot'
    WebUI.takeScreenshot()

    'Print error'
    not_run: CustomKeywords.'custompkg.Console.printConsole'('New Temp Error - Failed to create temp employees')

    'Close browser'
    WebUI.closeBrowser()
}

'Specify the first name'
WebUI.setText(findTestObject('Page_Temp Management/Temp Edit/input_FirstName'), td_FIRST)

'Specify the last name'
WebUI.setText(findTestObject('Page_Temp Management/Temp Edit/input_LastName'), td_LAST)

'Specify the email address'
WebUI.setText(findTestObject('Page_Temp Management/Temp Edit/input_Email'), td_EMAIL)

'Select the Shift'
WebUI.selectOptionByLabel(findTestObject('Page_Temp Management/Temp Edit/select_Shift'), td_SHIFT, false)

'Select the Supervisor name'
not_run: WebUI.selectOptionByLabel(findTestObject('Page_Temp Management/Temp Edit/select_SuperName'), td_SUPER_NAME, false)

'Select the Department name'
WebUI.selectOptionByLabel(findTestObject('Page_Temp Management/Temp Edit/select_Department'), td_DEPT, false)

'Specify the Code Expire Date'
WebUI.setText(findTestObject('Page_Temp Management/Temp Edit/input_CodeExpireDate'), td_EXPIRE)

'Specify the Hire Date'
WebUI.setText(findTestObject('Page_Temp Management/Temp Edit/input_HireDate'), td_HIRE)

'Specify any notes'
WebUI.setText(findTestObject('Page_Temp Management/Temp Edit/input_NotesField'), td_NOTES)

'Check/Uncheck Punch By Finger option'
if (td_FINGER) {
    WebUI.check(findTestObject('Page_Temp Management/Temp Edit/label_PunchByFinger_chkbox'))
} else {
    WebUI.uncheck(findTestObject('Page_Temp Management/Temp Edit/label_PunchByFinger_chkbox'))
}

'Check/Uncheck Punch By Bar Code option'
if (td_BARCODE) {
    not_run: WebUI.check(findTestObject('Page_Temp Management/Temp Edit/label_PunchByCode_chkbox'))
} else {
    WebUI.uncheck(findTestObject('Page_Temp Management/Temp Edit/label_PunchByCode_chkbox'))
}

'Check/Uncheck Active option'
if (td_ACTIVE) {
    WebUI.check(findTestObject('Page_Temp Management/Temp Edit/label_Active_chkbox'))
} else {
    WebUI.uncheck(findTestObject('Page_Temp Management/Temp Edit/label_Active_chkbox'))
}

'Check/Uncheck Supervisor option'
if (td_SUPERVISOR) {
    WebUI.check(findTestObject('Page_Temp Management/Temp Edit/label_Supervisor_chkbox'))
} else {
    WebUI.uncheck(findTestObject('Page_Temp Management/Temp Edit/label_Supervisor_chkbox'))
}

'Click [Save] to save the newly created temp employee'
WebUI.click(findTestObject('Page_Temp Management/Temp Edit/button_Save'))

'Verify Save Successful confirmation'
if (WebUI.verifyElementVisible(findTestObject('Page_Temp Management/Temp Edit/div_Save Successful'))) {
    'Verify the Temp Edit section is no longer displayed'
    WebUI.verifyElementNotVisibleInViewport(findTestObject('Page_Temp Management/Temp Edit/div_Temp_Edit_Section'), GlobalVariable.g_MIN_TO)

    'Verify ID CODE column'
    WebUI.verifyEqual(WebUI.getAttribute(findTestObject('Page_Temp Management/Temp Edit/input_EmployeeCode'), 'value'), 
        WebUI.getText(findTestObject('Page_Temp Management/Data Table/table_IDcode')))

    'Verify COMPANY column'
    WebUI.verifyElementText(findTestObject('Page_Temp Management/Data Table/table_Company'), td_COMPANY)

    'Verify FACILITY column'
    WebUI.verifyElementText(findTestObject('Page_Temp Management/Data Table/table_Facility'), td_FACILITY)

    'Verify CATEGORY column'
    WebUI.verifyElementText(findTestObject('Page_Temp Management/Data Table/table_Dept'), td_DEPT)

    'Verify FIRST NAME column'
    WebUI.verifyElementText(findTestObject('Page_Temp Management/Data Table/table_First'), td_FIRST)

    'Verify LAST NAME column'
    WebUI.verifyElementText(findTestObject('Page_Temp Management/Data Table/table_Last'), td_LAST)

    'Verify SUPERVISOR NAME column'
    not_run: WebUI.verifyElementText(findTestObject('Page_Temp Management/Data Table/table_SuperName'), td_SUPER_NAME)

    'Verify REPORT TO column'
    WebUI.verifyElementText(findTestObject('Page_Temp Management/Data Table/table_ReportTo'), td_NOTES)

    'Verify CATEGORY column'
    WebUI.verifyElementText(findTestObject('Page_Temp Management/Data Table/table_Category'), td_CATEGORY)

    'Verify JOB column'
    WebUI.verifyElementText(findTestObject('Page_Temp Management/Data Table/table_JobPosition'), td_JOB)

    'Verify EMAIL column'
    WebUI.verifyElementText(findTestObject('Page_Temp Management/Data Table/table_Email'), td_EMAIL)

    'Verify SHIFT column'
    WebUI.verifyElementText(findTestObject('Page_Temp Management/Data Table/table_Shift'), td_SHIFT)

    WS.comment('Verify data table')
} else {
    'Take screenshot'
    WebUI.takeScreenshot()

    'Print error'
    not_run: CustomKeywords.'custompkg.Console.printConsole'('New Temp Error - Failed to create temp employees')

    'Close browser'
    WebUI.closeBrowser()
}

def Read_Temp_Data() {
    td_COMPANY = findTestData(td_TEMP_INPUT).getValue('COMPANY', 1)

    td_FACILITY = findTestData(td_TEMP_INPUT).getValue('FACILITY', 1)

    td_CATEGORY = findTestData(td_TEMP_INPUT).getValue('CATEGORY', 1)

    td_FIRST = findTestData(td_TEMP_INPUT).getValue('FIRST_NAME', 1)

    td_LAST = findTestData(td_TEMP_INPUT).getValue('LAST_NAME', 1)

    td_EMAIL = findTestData(td_TEMP_INPUT).getValue('EMAIL', 1)

    td_ECODE = findTestData(td_TEMP_INPUT).getValue('ECODE', 1)

    td_SHIFT = findTestData(td_TEMP_INPUT).getValue('SHIFT', 1)

    td_SUPER_NAME = findTestData(td_TEMP_INPUT).getValue('SUPER_NAME', 1)

    td_JOB = findTestData(td_TEMP_INPUT).getValue('JOB', 1)

    td_DEPT = findTestData(td_TEMP_INPUT).getValue('DEPT', 1)

    td_EXPIRE = new Date(findTestData(td_TEMP_INPUT).getValue('EXPIRE', 1)).format('MM/dd/yyyy HH:MM')

    td_HIRE = new Date(findTestData(td_TEMP_INPUT).getValue('HIRE', 1)).format('MM/dd/yyyy')

    td_NOTES = findTestData(td_TEMP_INPUT).getValue('NOTES', 1)

    td_FINGER = findTestData(td_TEMP_INPUT).getValue('FINGER', 1)

    td_BARCODE = findTestData(td_TEMP_INPUT).getValue('BARCODE', 1)

    td_ACTIVE = findTestData(td_TEMP_INPUT).getValue('ACTIVE', 1)

    td_SUPERVISOR = findTestData(td_TEMP_INPUT).getValue('SUPERVISOR', 1)
}

