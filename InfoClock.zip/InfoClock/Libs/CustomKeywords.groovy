
/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */

import java.lang.String


def static "custompkg.Console.printConsole"(
    	String msg	) {
    (new custompkg.Console()).printConsole(
        	msg)
}

def static "custompkg.Timestamp.getDate"() {
    (new custompkg.Timestamp()).getDate()
}
