<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h1_Temp Edit</name>
   <tag></tag>
   <elementGuidId>f3910ba6-817a-4004-b43f-7165ca0e9edb</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//h1[@class = 'section-label h2section-label' and (contains(text(), 'Temp Edit') or contains(., 'Temp Edit'))]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h1</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>section-label h2section-label</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>contains</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Temp Edit</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;EmployeeEditPanel&quot;)/div[@class=&quot;grid-100&quot;]/div[@class=&quot;grid-content&quot;]/div[@class=&quot;grid-parent grid-100 container&quot;]/h1[@class=&quot;section-label h2section-label&quot;]</value>
   </webElementProperties>
</WebElementEntity>
