<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h1_Search</name>
   <tag></tag>
   <elementGuidId>80c317ea-cb73-44d3-ab41-dddccc930ef9</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h1</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>section-label h2section-label</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>contains</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Search</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;sitecontent&quot;)/div[@class=&quot;grid-content&quot;]/div[@class=&quot;grid-100&quot;]/div[@class=&quot;grid-content&quot;]/div[@id=&quot;TempEmployeeManagement&quot;]/h1[@class=&quot;section-label h2section-label&quot;]</value>
   </webElementProperties>
</WebElementEntity>
