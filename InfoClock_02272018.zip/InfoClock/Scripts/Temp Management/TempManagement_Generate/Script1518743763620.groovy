import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory as CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as MobileBuiltInKeywords
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testcase.TestCaseFactory as TestCaseFactory
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testdata.TestDataFactory as TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository as ObjectRepository
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WSBuiltInKeywords
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUiBuiltInKeywords
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable

'Login InfoClock'
WebUI.callTestCase(findTestCase('LoginInfoClock'), [('filename') : '\\LoginError.jpg', ('filepath') : 'C:\\Users\\cwright\\Automated Test Results\\InfoClock\\'], 
    FailureHandling.CONTINUE_ON_FAILURE)

'Hover over Configuration menu'
WebUI.mouseOver(findTestObject('Page_Home/img_mm_Configuration'))

'Wait for Temp Management to appear in menu'
WebUI.waitForElementVisible(findTestObject('Page_Home/span_Temp Management'), GlobalVariable.g_MIN_TO)

'Click Temp Management to view page'
WebUI.click(findTestObject('Page_Home/span_Temp Management'))

'Wait for page to load'
WebUI.waitForPageLoad(0)

'Scroll to Search field'
WebUI.scrollToElement(findTestObject('Page_Temp Management/Generate Temp/h1_GenerateTemp'), GlobalVariable.g_MIN_TO)

'Click Company drop-down'
not_run: WebUI.click(findTestObject('Page_Temp Management/Search/select_Company'))

'Click the Company name using test data'
not_run: WebUI.selectOptionByLabel(findTestObject('Page_Temp Management/Search/select_Company'), findTestData('InfoClock_Temp_Input XL').getValue(
        'COMPANY', 1), false)

not_run: WebUI.click(findTestObject('Page_Temp Management/Search/select_Facility'))

'Click the Facility name using test data'
not_run: WebUI.selectOptionByLabel(findTestObject('Page_Temp Management/Search/select_Facility'), findTestData('InfoClock_Temp_Input XL').getValue(
        'FACILITY', 1), false)

not_run: WebUI.click(findTestObject('Page_Temp Management/Search/select_Category'))

'Click the Category name using test data'
not_run: WebUI.selectOptionByLabel(findTestObject('Page_Temp Management/Search/select_Category'), findTestData('InfoClock_Temp_Input XL').getValue(
        'CATEGORY', 1), false)

not_run: WebUI.click(findTestObject('Page_Temp Management/Search/input_JobPosition'))

'Specify the job position'
not_run: WebUI.setText(findTestObject('Page_Temp Management/Search/input_JobPosition'), findTestData('InfoClock_Temp_Input XL').getValue(
        'POSITION', 1))

'Click [New Temp] button'
not_run: WebUI.click(findTestObject('Page_Temp Management/Search/button_New Temp'))

not_run: WebUI.scrollToElement(findTestObject('Page_Temp Management/Search/button_New Temp'), GlobalVariable.g_MIN_TO)

'Check if Temp Edit field is present'
not_run: if (WebUI.verifyElementVisibleInViewport(findTestObject('Page_Temp Management/Temp Edit/h1_Temp Edit'), GlobalVariable.g_SHORT_TO)) {
    'Verify Punch By Bar Code is checked'
    not_run: WebUI.verifyElementChecked(findTestObject(null), 0)

    'Verify Company in New Temp section'
    not_run: WebUI.verifyOptionSelectedByLabel(findTestObject('Page_Temp Management/Temp Edit/select_Company'), findTestData(
            'InfoClock_Temps').getValue('COMPANY', 1), false, GlobalVariable.g_MIN_TO)

    'Verify Facility in New Temp section'
    not_run: WebUI.verifyOptionSelectedByLabel(findTestObject('Page_Temp Management/Temp Edit/select_Facility'), findTestData(
            'InfoClock_Temps').getValue('FACILITY', 1), false, GlobalVariable.g_MIN_TO)

    'Verify Category in New Temp section'
    not_run: WebUI.verifyOptionSelectedByLabel(findTestObject('Page_Temp Management/Temp Edit/select_Category'), findTestData(
            'InfoClock_Temps').getValue('CATEGORY', 1), false, GlobalVariable.g_MIN_TO)

    'Verify Position in New Temp section'
    not_run: WebUI.verifyElementAttributeValue(findTestObject('Page_Temp Management/Temp Edit/input_JobPosition'), 'value', 
        findTestData('InfoClock_Temp_Input XL').getValue('POSITION', 1), 0)

    'Verify ID CODE column and Employee Code field display the same ID'
    not_run: WebUI.verifyEqual(WebUI.getAttribute(findTestObject('Page_Temp Management/Temp Edit/input_EmployeeCode'), 'value'), 
        WebUI.getText(findTestObject('Page_Temp Management/Data Table/table_IDcode')))

    'Verify Department is "Warehouse"'
    not_run: Mobile.verifyElementText(findTestObject(null), '', FailureHandling.CONTINUE_ON_FAILURE)

    'Verify Hire Date is the current date'
    not_run: Mobile.verifyElementText(findTestObject(null), '', FailureHandling.CONTINUE_ON_FAILURE)

    'Verify Punch By Bar Code is checked'
    not_run: WebUI.verifyElementChecked(findTestObject(null), 0)

    'Verify Active is checked'
    not_run: WebUI.verifyElementChecked(findTestObject(null), 0)
} else {
    'Take screenshot'
    not_run: WebUI.takeScreenshot()

    'Print error'
    not_run: CustomKeywords.'custompkg.Console.printConsole'('New Temp Error - Failed to create temp employees')

    'Close browser'
    not_run: WebUI.closeBrowser()
}

WS.comment('Specify first name')

WS.comment('Specify last name')

WS.comment('Specify email')

WS.comment('Specify shift')

WS.comment('Specify supervisor')

WS.comment('Specify department')

WS.comment('Specify Code Expire Date')

WS.comment('Specify Hire Date')

WS.comment('Specify Notes')

WS.comment('Specify Punch by Finger')

WS.comment('Specify Punch by Bar Code')

WS.comment('Specify Active')

WS.comment('Specify Supervisor')

WS.comment('Save')

//WS.comment('Save & Print')
WS.comment('Check for Save Successful')

WS.comment('Temp Edit section is removed')

WS.comment('Verify data table')

